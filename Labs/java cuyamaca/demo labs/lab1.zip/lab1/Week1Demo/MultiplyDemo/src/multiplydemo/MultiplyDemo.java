/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplydemo;

/**
 *
 * @author john.gerstenberg
 */
public class MultiplyDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // instantiate our custom form
        // ClassName varName = new ClassName ()
        MultiplyForm myForm = new MultiplyForm();
        
        // now that we instantiated the form, make it visible
        myForm.setVisible(true);
    }
    
}
