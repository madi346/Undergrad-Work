/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2energybill;

/**
 *
 * @author Madison
 */
public class Lab2EnergyBill {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // To do: instantiate and show our form
        EnergyBillForm myForm = new EnergyBillForm(); 
        myForm.setVisible(true); 
       
    }
    
}
