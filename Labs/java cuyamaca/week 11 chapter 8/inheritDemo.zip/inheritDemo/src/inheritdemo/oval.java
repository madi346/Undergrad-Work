/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritdemo;

import java.awt.*;
/**
 *
 * @author John
 */
// class that inherits from the abstract shape class (note the extends shape)
public class oval extends shape {

  private final int DEF_SIZE = 20;
  private int length;
  private int width;

  public oval() {
    // call the constructor in the base class
    super("oval");

    // add some behavior of our own
    length = DEF_SIZE;
    width = DEF_SIZE;
    color = Color.RED; // default color
    posX = 1;
    posY = 1;
  }

   public oval(Color aColor, int x, int y, int aLength, int aWidth, Graphics g) {
     // call the constructor in the base class
    super("oval");
    posX = x;
    posY = y;
    length = aLength;
    width = aWidth;
    color = aColor;
    paint(g);
  }
  

  public void paint(Graphics g) {
    g.setColor(color);
    g.fillOval(posX, posY, width, length);
  }
}
