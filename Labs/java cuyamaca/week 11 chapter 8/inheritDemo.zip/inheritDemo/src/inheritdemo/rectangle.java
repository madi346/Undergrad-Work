/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package inheritdemo;

import java.awt.*;

/**
 *
 * @author John
 */

// class that inherits from the abstract shape class (note the extends shape)
public class rectangle extends shape {
  private final int DEF_SIZE = 20;
  private int length;
  private int width;

  // default constructor
  public rectangle() {
    // call the constructor in the base class first!
    super("square");

    // Add some behavior of our own. Since these data members were
    // declared protected in the superclass, we have direct access
    // to these in the subclass
    length = DEF_SIZE;
    width = DEF_SIZE;
    color = Color.BLUE; // default color
    posX = 1;
    posY = 1;
  }

  // custom constructor
  public rectangle(Color aColor, int x, int y, int aLength, int aWidth) {
    // Call the constructor in the base class first
    super("rectangle");

    // now add some custom behavior
    length = aLength;
    width = aWidth;
    color = aColor;
    posX = x;
    posY = y;
  }

  // override/implement the paint() method
  public void paint(Graphics g) {
    g.setColor(color);
    g.fillRect(posX, posY, width, length);
  }
} // end rectangle class
