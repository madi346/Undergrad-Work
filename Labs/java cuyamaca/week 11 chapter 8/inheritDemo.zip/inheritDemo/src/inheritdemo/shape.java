package inheritdemo;

import java.awt.*;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author John
 */

abstract public class shape {
  // instead of private, declare the data members as protected so they
  // are visible to derived classes
  protected String name;
  protected Color color;
  protected int posX;
  protected int posY;

  // default constructor
  public shape() {
    name = "";
  }

  // custom constrcutor
  public shape(String shapeName) {
    name = shapeName;
  }

  // set/get methods implemented in the base class so we don't have to do it
  // in the classes derived from the shape class
  public void setName(String aName) {
    name = aName;
  }

  public String getName() {
    return name;
  }

  public void setColor(Color aColor) {
    color = aColor;
  }

  public Color getColor() {
    return color;
  }

  public void setX(int x) {
    posX = x;
  }

  public int getX() {
    return posX;
  }

  public void setY(int y) {
    posY = y;
  }

  public int getY() {
    return posY;
  }

  // Java abstract method. We have to override this in any derived classes
  abstract public void paint(Graphics g);
}
