/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7exercises;

/**
 *
 * @author Madison
 */
public class Lab7Exercises {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        lab7Form myForm = new lab7Form(); 
        myForm.setVisible(true);  
    }
    
}
