/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arraydemo;

/**
 *
 * @author John
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       arrayDemoForm arrayDemo = new arrayDemoForm();
       arrayDemo.setVisible(true);
    }

}
